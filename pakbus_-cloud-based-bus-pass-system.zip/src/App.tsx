import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bus, 
  MapPin, 
  Search, 
  ChevronRight, 
  CheckCircle2, 
  CreditCard, 
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import { BusRoute } from './types';

const PAK_CITIES = ["Karachi", "Lahore", "Islamabad", "Faisalabad", "Multan", "Peshawar", "Quetta"];

export default function App() {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [routes, setRoutes] = useState<BusRoute[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<BusRoute | null>(null);
  const [bookedSeats, setBookedSeats] = useState<number[]>([]);
  const [selectedSeat, setSelectedSeat] = useState<number | null>(null);
  const [step, setStep] = useState<'search' | 'seats' | 'payment' | 'success'>('search');
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [bookingId, setBookingId] = useState<number | null>(null);

  const searchRoutes = async () => {
    if (!origin || !destination) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/routes?origin=${origin}&destination=${destination}`);
      const data = await res.json();
      setRoutes(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchBookedSeats = async (routeId: number) => {
    try {
      const res = await fetch(`/api/routes/${routeId}/booked-seats`);
      const data = await res.json();
      setBookedSeats(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSelectRoute = (route: BusRoute) => {
    setSelectedRoute(route);
    fetchBookedSeats(route.id);
    setStep('seats');
  };

  const handleBooking = async () => {
    if (!selectedRoute || selectedSeat === null) return;
    setLoading(true);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          route_id: selectedRoute.id,
          passenger_name: formData.name,
          passenger_email: formData.email,
          seat_number: selectedSeat
        })
      });
      const data = await res.json();
      if (res.ok) {
        setBookingId(data.id);
        setStep('success');
      } else {
        alert(data.error || 'Booking failed');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-slate-900 font-sans">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="bg-emerald-600 p-2 rounded-lg">
            <Bus className="text-white w-6 h-6" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800">PakBus</span>
        </div>
        <div className="hidden md:flex gap-8 text-sm font-medium text-slate-500">
          <a href="#" className="hover:text-emerald-600 transition-colors">My Bookings</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Routes</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Support</a>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {step === 'search' && (
            <motion.div
              key="search"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="text-center space-y-4">
                <h1 className="text-5xl font-bold tracking-tight text-slate-900">
                  Travel Across <span className="text-emerald-600">Pakistan</span>
                </h1>
                <p className="text-slate-500 text-lg max-w-2xl mx-auto">
                  Book your bus tickets instantly with our cloud-powered system. Fast, secure, and reliable.
                </p>
              </div>

              {/* Search Card */}
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                      <MapPin className="w-3 h-3" /> From
                    </label>
                    <select 
                      value={origin}
                      onChange={(e) => setOrigin(e.target.value)}
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all appearance-none"
                    >
                      <option value="">Select Origin</option>
                      {PAK_CITIES.map(city => <option key={city} value={city}>{city}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                      <MapPin className="w-3 h-3" /> To
                    </label>
                    <select 
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all appearance-none"
                    >
                      <option value="">Select Destination</option>
                      {PAK_CITIES.map(city => <option key={city} value={city}>{city}</option>)}
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button 
                      onClick={searchRoutes}
                      disabled={loading}
                      className="w-full bg-slate-900 text-white p-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-50"
                    >
                      {loading ? 'Searching...' : <><Search className="w-5 h-5" /> Find Buses</>}
                    </button>
                  </div>
                </div>
              </div>

              {/* Results */}
              <div className="space-y-4">
                {routes.length > 0 ? (
                  routes.map((route) => (
                    <motion.div 
                      key={route.id}
                      whileHover={{ y: -4 }}
                      className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6"
                    >
                      <div className="flex items-center gap-8">
                        <div className="text-center">
                          <p className="text-2xl font-bold">{route.departure_time}</p>
                          <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">{route.origin}</p>
                        </div>
                        <div className="flex flex-col items-center gap-1">
                          <div className="w-24 h-[2px] bg-slate-200 relative">
                            <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-white px-2">
                              <Bus className="w-4 h-4 text-emerald-600" />
                            </div>
                          </div>
                          <span className="text-[10px] font-bold text-slate-300 uppercase">8 Hours</span>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold">{route.arrival_time}</p>
                          <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">{route.destination}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-8 w-full md:w-auto justify-between md:justify-end">
                        <div className="text-right">
                          <p className="text-2xl font-bold text-emerald-600">Rs. {route.price.toLocaleString()}</p>
                          <p className="text-xs font-medium text-slate-400">{route.bus_type} Class</p>
                        </div>
                        <button 
                          onClick={() => handleSelectRoute(route)}
                          className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all active:scale-95"
                        >
                          Select
                        </button>
                      </div>
                    </motion.div>
                  ))
                ) : origin && destination && !loading && (
                  <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-300">
                    <Info className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No buses found for this route today.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {step === 'seats' && selectedRoute && (
            <motion.div
              key="seats"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8"
            >
              <div className="lg:col-span-2 space-y-6">
                <button 
                  onClick={() => setStep('search')}
                  className="text-sm font-semibold text-slate-400 flex items-center gap-2 hover:text-slate-600"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" /> Back to search
                </button>
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <h2 className="text-2xl font-bold mb-8">Select Your Seat</h2>
                  <div className="max-w-xs mx-auto bg-slate-50 p-6 rounded-2xl border border-slate-100">
                    <div className="flex justify-end mb-8">
                      <div className="w-10 h-10 bg-slate-300 rounded-lg flex items-center justify-center">
                        <Zap className="w-5 h-5 text-slate-500" />
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-3">
                      {Array.from({ length: 40 }).map((_, i) => {
                        const seatNum = i + 1;
                        const isBooked = bookedSeats.includes(seatNum);
                        const isSelected = selectedSeat === seatNum;
                        return (
                          <button
                            key={seatNum}
                            disabled={isBooked}
                            onClick={() => setSelectedSeat(seatNum)}
                            className={`
                              h-10 rounded-lg text-xs font-bold transition-all
                              ${isBooked ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 
                                isSelected ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 scale-110' : 
                                'bg-white border border-slate-200 text-slate-600 hover:border-emerald-500'}
                            `}
                          >
                            {seatNum}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="mt-8 flex justify-center gap-6 text-xs font-bold uppercase tracking-wider">
                    <div className="flex items-center gap-2"><div className="w-4 h-4 bg-white border border-slate-200 rounded"></div> Available</div>
                    <div className="flex items-center gap-2"><div className="w-4 h-4 bg-slate-200 rounded"></div> Booked</div>
                    <div className="flex items-center gap-2"><div className="w-4 h-4 bg-emerald-600 rounded"></div> Selected</div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
                  <h3 className="font-bold text-lg">Booking Summary</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Route</span>
                      <span className="font-semibold">{selectedRoute.origin} to {selectedRoute.destination}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Seat Number</span>
                      <span className="font-semibold">{selectedSeat || 'Not selected'}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Bus Type</span>
                      <span className="font-semibold">{selectedRoute.bus_type}</span>
                    </div>
                    <div className="pt-4 border-t border-slate-100 flex justify-between items-end">
                      <span className="text-slate-400 text-sm">Total Amount</span>
                      <span className="text-2xl font-bold text-emerald-600">Rs. {selectedRoute.price.toLocaleString()}</span>
                    </div>
                  </div>
                  <button 
                    disabled={selectedSeat === null}
                    onClick={() => setStep('payment')}
                    className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50"
                  >
                    Continue to Payment
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'payment' && selectedRoute && (
            <motion.div
              key="payment"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-2xl mx-auto space-y-8"
            >
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Secure Checkout</h2>
                  <div className="flex items-center gap-2 text-emerald-600 text-xs font-bold uppercase tracking-widest">
                    <ShieldCheck className="w-4 h-4" /> SSL Encrypted
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Full Name</label>
                      <input 
                        type="text"
                        placeholder="Enter your name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address</label>
                      <input 
                        type="email"
                        placeholder="email@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <CreditCard className="w-6 h-6 text-slate-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold">Payment Method</p>
                        <p className="text-xs text-slate-400">JazzCash / EasyPaisa / Credit Card</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold text-emerald-600 uppercase">Simulated</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button 
                      onClick={() => setStep('seats')}
                      className="flex-1 py-4 rounded-2xl font-bold border border-slate-200 hover:bg-slate-50 transition-all"
                    >
                      Back
                    </button>
                    <button 
                      disabled={!formData.name || !formData.email || loading}
                      onClick={handleBooking}
                      className="flex-[2] bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 active:scale-95 disabled:opacity-50"
                    >
                      {loading ? 'Processing...' : `Pay Rs. ${selectedRoute.price.toLocaleString()}`}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'success' && selectedRoute && (
            <motion.div
              key="success"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-md mx-auto text-center space-y-8"
            >
              <div className="bg-white p-12 rounded-[40px] border border-slate-200 shadow-xl space-y-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-emerald-600"></div>
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold">Ticket Confirmed!</h2>
                  <p className="text-slate-400">Your trip from {selectedRoute.origin} to {selectedRoute.destination} is booked.</p>
                </div>
                
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 text-left space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Booking ID</span>
                    <span className="font-mono font-bold text-emerald-600">#PB-{bookingId}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Seat Number</span>
                    <span className="font-bold">{selectedSeat}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Passenger</span>
                    <span className="font-bold">{formData.name}</span>
                  </div>
                </div>

                <button 
                  onClick={() => window.location.reload()}
                  className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-all"
                >
                  Book Another Ticket
                </button>
              </div>
              <p className="text-slate-400 text-sm">A confirmation email has been sent to {formData.email}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer / Documentation Section */}
      <footer className="bg-white border-t border-slate-200 mt-24 py-16 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold">System Architecture</h3>
            <div className="space-y-4 text-slate-500 text-sm leading-relaxed">
              <p>
                This cloud-native application is designed for high availability and scalability. 
                The architecture leverages a <strong>Load Balancer</strong> to distribute traffic across multiple 
                <strong>Auto-Scaling</strong> EC2 instances.
              </p>
              <ul className="space-y-2 list-disc pl-4">
                <li><strong>Frontend:</strong> React SPA served via CloudFront/S3.</li>
                <li><strong>Backend:</strong> Node.js Express API on Auto-Scaling Groups.</li>
                <li><strong>Database:</strong> Amazon RDS (PostgreSQL/MySQL) with Multi-AZ for reliability.</li>
                <li><strong>Caching:</strong> Redis (ElastiCache) for session and route caching.</li>
              </ul>
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-bold">Security & Scalability</h3>
            <div className="space-y-4 text-slate-500 text-sm leading-relaxed">
              <p>
                To prevent ticket duplication, we use <strong>Database Transactions</strong> and unique constraints 
                on (route_id, seat_number).
              </p>
              <ul className="space-y-2 list-disc pl-4">
                <li><strong>Security:</strong> HTTPS (ACM), IAM Roles, and VPC Isolation.</li>
                <li><strong>Scalability:</strong> Horizontal scaling based on CPU/Request count metrics.</li>
                <li><strong>Deployment:</strong> CI/CD via GitHub Actions to AWS CodeDeploy.</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="max-w-5xl mx-auto mt-16 pt-8 border-t border-slate-100 flex justify-between items-center text-xs font-bold uppercase tracking-widest text-slate-400">
          <span>PakBus © 2026</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-emerald-600">Architecture</a>
            <a href="#" className="hover:text-emerald-600">API Docs</a>
            <a href="#" className="hover:text-emerald-600">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
