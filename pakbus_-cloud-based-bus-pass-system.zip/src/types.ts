export interface BusRoute {
  id: number;
  origin: string;
  destination: string;
  departure_time: string;
  arrival_time: string;
  price: number;
  bus_type: string;
  total_seats: number;
}

export interface Booking {
  id?: number;
  route_id: number;
  passenger_name: string;
  passenger_email: string;
  seat_number: number;
  payment_status: string;
  booking_date?: string;
}
