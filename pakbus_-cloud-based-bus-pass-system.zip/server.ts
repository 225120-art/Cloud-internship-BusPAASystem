import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("bus_system.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origin TEXT NOT NULL,
    destination TEXT NOT NULL,
    departure_time TEXT NOT NULL,
    arrival_time TEXT NOT NULL,
    price INTEGER NOT NULL,
    bus_type TEXT NOT NULL,
    total_seats INTEGER DEFAULT 40
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    route_id INTEGER NOT NULL,
    passenger_name TEXT NOT NULL,
    passenger_email TEXT NOT NULL,
    seat_number INTEGER NOT NULL,
    payment_status TEXT DEFAULT 'pending',
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(id)
  );
`);

// Seed data if empty
const routeCount = db.prepare("SELECT COUNT(*) as count FROM routes").get() as { count: number };
if (routeCount.count === 0) {
  const insertRoute = db.prepare(`
    INSERT INTO routes (origin, destination, departure_time, arrival_time, price, bus_type)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const pakCities = ["Karachi", "Lahore", "Islamabad", "Faisalabad", "Multan", "Peshawar", "Quetta"];
  
  for (let i = 0; i < pakCities.length; i++) {
    for (let j = 0; j < pakCities.length; j++) {
      if (i !== j) {
        insertRoute.run(pakCities[i], pakCities[j], "09:00 AM", "05:00 PM", 2500 + Math.floor(Math.random() * 2000), "Luxury");
        insertRoute.run(pakCities[i], pakCities[j], "09:00 PM", "05:00 AM", 2200 + Math.floor(Math.random() * 1500), "Executive");
      }
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get("/api/routes", (req, res) => {
    const { origin, destination } = req.query;
    let query = "SELECT * FROM routes";
    const params = [];

    if (origin && destination) {
      query += " WHERE origin = ? AND destination = ?";
      params.push(origin, destination);
    }

    const routes = db.prepare(query).all(...params);
    res.json(routes);
  });

  app.get("/api/routes/:id/booked-seats", (req, res) => {
    const bookings = db.prepare("SELECT seat_number FROM bookings WHERE route_id = ?").all(req.params.id) as { seat_number: number }[];
    res.json(bookings.map(b => b.seat_number));
  });

  app.post("/api/bookings", (req, res) => {
    const { route_id, passenger_name, passenger_email, seat_number } = req.body;

    // Prevent double booking (Race condition protection)
    const existing = db.prepare("SELECT id FROM bookings WHERE route_id = ? AND seat_number = ?").get(route_id, seat_number);
    if (existing) {
      return res.status(400).json({ error: "Seat already booked" });
    }

    try {
      const info = db.prepare(`
        INSERT INTO bookings (route_id, passenger_name, passenger_email, seat_number, payment_status)
        VALUES (?, ?, ?, ?, 'paid')
      `).run(route_id, passenger_name, passenger_email, seat_number);

      res.json({ id: info.lastInsertRowid, message: "Booking successful" });
    } catch (err) {
      res.status(500).json({ error: "Booking failed" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
