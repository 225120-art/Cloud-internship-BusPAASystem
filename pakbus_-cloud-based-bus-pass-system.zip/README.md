# PakBus: Cloud-Based Bus Pass System (Pakistan)

A comprehensive, cloud-native city-to-city bus booking system designed for the Pakistani market.

## 🚀 System Architecture

- **Frontend**: React 19 with Tailwind CSS and Framer Motion for a premium, responsive UI.
- **Backend**: Node.js (Express) handling RESTful API requests.
- **Database**: 
  - Local: SQLite (better-sqlite3) for development.
  - Production: Amazon RDS (PostgreSQL/MySQL) with Multi-AZ deployment.
- **Cloud Infrastructure**:
  - **Load Balancer**: AWS Application Load Balancer (ALB) for traffic distribution.
  - **Auto-Scaling**: EC2 Auto Scaling Groups (ASG) based on CPU utilization.
  - **Storage**: Amazon S3 for static assets and ticket PDF storage.
  - **CDN**: Amazon CloudFront for low-latency frontend delivery.

## 📊 Database Schema (RDS)

### Routes Table
- `id`: Primary Key
- `origin`: VARCHAR(100)
- `destination`: VARCHAR(100)
- `departure_time`: TIMESTAMP
- `arrival_time`: TIMESTAMP
- `price`: DECIMAL(10, 2)
- `bus_type`: ENUM('Luxury', 'Executive', 'Standard')
- `total_seats`: INT (Default 40)

### Bookings Table
- `id`: Primary Key
- `route_id`: Foreign Key (Routes)
- `passenger_name`: VARCHAR(255)
- `passenger_email`: VARCHAR(255)
- `seat_number`: INT
- `payment_status`: ENUM('pending', 'paid', 'failed')
- `booking_date`: TIMESTAMP

## 💳 Payment Logic Simulation
The system simulates PKR payments via JazzCash/EasyPaisa. In a production environment, this would integrate with the JazzCash API or Stripe.

## 🛠 Deployment Guide (AWS)

1. **VPC Setup**: Create a VPC with public and private subnets.
2. **Database**: Provision an RDS instance in the private subnet.
3. **Compute**: 
   - Create a Launch Template with the Node.js environment.
   - Set up an Auto Scaling Group.
4. **Networking**: Configure an Application Load Balancer to route traffic to the ASG.
5. **Security**: 
   - Use Security Groups to restrict access (only ALB can talk to EC2, only EC2 can talk to RDS).
   - Enable HTTPS using AWS Certificate Manager (ACM).

## 🔒 Security Measures
- **SQL Injection Protection**: Using prepared statements/ORM.
- **XSS Protection**: React's built-in escaping.
- **Rate Limiting**: Express-rate-limit to prevent DDoS.
- **Data Encryption**: TLS for data in transit, AES-256 for data at rest in RDS.

## 🧪 Testing Strategy
- **Unit Testing**: Jest for backend logic.
- **Integration Testing**: Supertest for API endpoints.
- **Load Testing**: JMeter or k6 to verify auto-scaling triggers.
- **UI Testing**: Playwright for end-to-end booking flows.
